$(function(){
    someList = [ "paok" ]
    var url = window.location.href; 
    //var url = window.location.href;
    splitted = url.split("/");
    last = splitted[splitted.length-1];
    new_split = last.split(".");
    content = new_split[0];
    $.each(someList, function(n, elem) {
       $("#breadcrumb_path").append("<li><b> > </b> </li>"); 
        $("#breadcrumb_path").append("<li>"+"<a class=\"home\" href=\"" +url+ "\" id=\"Home\">" + content +"</a></li>"); 
    });
});



