angular.module('meeting_part',[])

.controller('meeting_participants',function($scope){

	$scope.list=[
			{name:'Stayros Dag (admin)',img:'images/Batman-wallpaper-1080x1920.jpg'},
			{name:'Kwstas Madness',img:'1443455160_linux-server-system-platform-os-computer-penguin.png'},
			{name:'Giannhs Kalaitzos',img:'images/d5f89d10412f3ca9814f9d5314c4b3f1c00e78661d9a94028223ae8492c503f3.jpg'},
			{name:'Conference Room',img:'images/Conference-Room-Setup-Styles-Design-Idea-9.jpg'}
			];	

    
});







