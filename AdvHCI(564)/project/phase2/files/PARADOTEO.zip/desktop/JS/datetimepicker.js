$('#dateranger').daterangepicker({});
$('input[name=dateranger]').daterangepicker();
